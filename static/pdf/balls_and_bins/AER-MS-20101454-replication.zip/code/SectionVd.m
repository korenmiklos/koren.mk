% SECTION Vd: Introducing fundamental zeros.
%
%   Computes the fraction of zeros in product-country trade flows and the
%   share of exporters given a fraction of fundamental zeros.
%

clear;

%% Calibration parameters

bs=36000;               % Ball size in dollars

mu_sales=13.4;          % Log-normal parameters in dollars
sigma=2.44;   

exp_share=.139;         % Share of export revenue -- bin size

%% Load data for bin sizes in products and shipment shares for destinations

% Bin sizes for products
s=csvread('../data/census/hs10shares.csv');
K_prod=length(s); % number of categories
if sum(s)~=1
    s=s/sum(s);
elseif min(s)<0
    error('Probabilities should be non-negative')
end
s_prod=s;

% Shipment shares for destinations
s=csvread('../data/census/countryshares.csv');
K_dest=length(s); % number of categories
if sum(s)~=1
    s=s/sum(s);
elseif min(s)<0
    error('Probabilities should be non-negative')
end
s_dest=s;

%% Log-normal distribution over number of balls

mu=mu_sales-log(bs);    % Log-normal parameters in balls

% determine upper cutoff
n_max = logninv(0.999,mu,sigma);

contgrid = [0.01:0.01:n_max];
N = length(contgrid);
% the number of balls given is rounded up
n = ceil(contgrid);

%Cumulative distribution function
ld_cdf = logncdf(contgrid,mu,sigma);

%Probability mass function
ld_pdf(1)=ld_cdf(1);
ld_pdf(2:N)=ld_cdf(2:N)-ld_cdf(1:N-1);

%Ensure probability distribution is proper
ld_pdf = ld_pdf/sum(ld_pdf);

%% Fraction of zeros in product-country flows

fundamental_share=0:.1:.5;
balls=ceil(s_dest*21579518);

s_long_vec=reshape(kron(s_dest,s_prod'),numel(kron(s_dest,s_prod')),1);
cut_offs=prctile(s_long_vec,fundamental_share*100);

% expected number of zeros
kc=zeros(length(s_dest),length(cut_offs));

for c=1:length(s_dest)
    for i=1:length(cut_offs)
        % start with all bins closed
        s=zeros(1,length(s_prod));
        % these bins are large enough to open
        open_bins=find(s_dest(c)*s_prod>=cut_offs(i));
        if isempty(open_bins)==1
            kc(c,i)=length(s_prod);
        else
            % open bins have the same size as the marginal distribution
            s(open_bins)=s_prod(open_bins);
            kc(c,i)=sum((1-s).^balls(c));
        end
    end
end

share_zeros=sum(kc,1)/length(s_dest)/length(s_prod);

%% Fraction of exporters
sh_exp=zeros(1,length(cut_offs));

for i=1:length(cut_offs)
    % start with all export bins closed
    s=zeros(1,length(n));
    % these export bins are large enough to open
    open_bins=find(ld_cdf>=fundamental_share(i));    
    if isempty(open_bins)==1
        sh_exp(1,i)=0;
    else
        % open bins have the same probability as the marginal distribution
        s(open_bins)=ld_pdf(open_bins);
        sh_exp(1,i)=s*(1-(1-exp_share).^n)';
    end
end


%% Display output

disp('Share of fundamental zeros among total bins')
disp(num2str(fundamental_share))
disp('Fraction of zeros in product-country flows')
disp(num2str(share_zeros))
disp('Share of exporters')
disp(num2str(sh_exp))

